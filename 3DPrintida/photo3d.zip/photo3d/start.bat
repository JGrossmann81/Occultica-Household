@echo off
cd /d "%~dp0"
if not exist env\Scripts\python.exe (echo Run setup.bat first. & pause & exit /b 1)
env\Scripts\python.exe server.py
pause
