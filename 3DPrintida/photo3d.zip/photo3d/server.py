"""3DPrintida photo helper. Runs on YOUR PC. Turns one photo into a 3D model with TripoSR (open source, MIT licence).
Start it with start.bat, then use the "Photo to 3D" tab on the 3DPrintida page. Nothing leaves your computer except
the one-time model download from Hugging Face."""
import io, json, os, sys, time, threading, types, traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("P3D_PORT", "8788"))
TSR_DIR = os.environ.get("TSR_DIR", os.path.join(HERE, "TripoSR"))
OUT = os.path.join(HERE, "outputs"); os.makedirs(OUT, exist_ok=True)
STATE = {"state": "starting", "msg": "Starting...", "device": "?"}
LOCK = threading.Lock()
M = {}

def say(msg, state=None):
    STATE["msg"] = msg
    if state: STATE["state"] = state
    print(msg, flush=True)

def install_mc_shim():
    """Use scikit-image marching cubes when torchmcubes is not installed (it needs a C++ compiler on Windows)."""
    try:
        import torchmcubes  # noqa
        return
    except Exception:
        pass
    import numpy as np, torch
    sys.path.insert(0, HERE)
    from mc_core import mc_numpy
    mod = types.ModuleType("torchmcubes")
    def marching_cubes(vol, thresh):
        v, f = mc_numpy(vol.detach().cpu().numpy(), float(thresh))
        return torch.from_numpy(v), torch.from_numpy(f)
    mod.marching_cubes = marching_cubes
    sys.modules["torchmcubes"] = mod
    say("Using the built-in marching cubes (no compiler needed).")

def load():
    try:
        say("Loading the AI model. The first run downloads about 1.7 GB, so this can take several minutes...", "loading")
        import torch
        if not os.path.isdir(os.path.join(TSR_DIR, "tsr")):
            raise RuntimeError("TripoSR folder not found: " + TSR_DIR + ". Run setup.bat first.")
        sys.path.insert(0, TSR_DIR)
        install_mc_shim()
        import numpy as np, rembg
        from PIL import Image
        from tsr.system import TSR
        from tsr.utils import remove_background, resize_foreground
        dev = "cuda:0" if torch.cuda.is_available() else "cpu"
        model = TSR.from_pretrained("stabilityai/TripoSR", config_name="config.yaml", weight_name="model.ckpt")
        model.renderer.set_chunk_size(8192)
        model.to(dev)
        M.update(torch=torch, np=np, rembg=rembg, Image=Image, model=model, dev=dev, rb=remove_background, rf=resize_foreground, sess=None)
        STATE["device"] = dev
        say("Ready on " + ("your graphics card." if dev.startswith("cuda") else "the CPU (slow: a few minutes per photo)."), "ready")
    except Exception as e:
        traceback.print_exc()
        say("Could not start: " + str(e), "error")

def make(data, res, strip, fg):
    torch, np, Image, model, dev = M["torch"], M["np"], M["Image"], M["model"], M["dev"]
    img = Image.open(io.BytesIO(data))
    if strip:
        if M["sess"] is None: M["sess"] = M["rembg"].new_session()
        img = M["rf"](M["rb"](img, M["sess"]), fg)
        arr = np.array(img).astype(np.float32) / 255.0
        arr = arr[:, :, :3] * arr[:, :, 3:4] + (1 - arr[:, :, 3:4]) * 0.5
        img = Image.fromarray((arr * 255.0).astype(np.uint8))
    else:
        img = img.convert("RGB")
    stamp = time.strftime("%Y%m%d_%H%M%S")
    img.save(os.path.join(OUT, stamp + "_input.png"))
    with torch.no_grad():
        codes = model([img], device=dev)
        mesh = model.extract_mesh(codes, False, resolution=res)[0]
    if dev.startswith("cuda"): torch.cuda.empty_cache()
    v, f = np.asarray(mesh.vertices), np.asarray(mesh.faces)
    lines = ["# TripoSR via 3DPrintida"]
    lines += ["v %.5f %.5f %.5f" % (a, b, c) for a, b, c in v]
    lines += ["f %d %d %d" % (a + 1, b + 1, c + 1) for a, b, c in f]
    text = "\n".join(lines) + "\n"
    with open(os.path.join(OUT, stamp + ".obj"), "w") as fh: fh.write(text)
    return text, len(f)

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
    def reply(self, code, body, ctype="application/json"):
        b = body.encode() if isinstance(body, str) else body
        self.send_response(code); self.cors()
        self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self): self.reply(204, "")
    def do_GET(self):
        if urlparse(self.path).path == "/ping": self.reply(200, json.dumps(dict(STATE, ok=True, app="3dprintida-photo3d")))
        else: self.reply(404, "{}")
    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/make": return self.reply(404, "{}")
        q = parse_qs(u.query)
        if STATE["state"] != "ready": return self.reply(503, json.dumps({"error": STATE["msg"]}))
        n = int(self.headers.get("Content-Length", "0")); data = self.rfile.read(n)
        try:
            res = max(128, min(512, int(q.get("res", ["320"])[0])))
            strip = q.get("rembg", ["1"])[0] != "0"
            with LOCK:
                t0 = time.time(); say("Working on a photo (%d KB, detail %d)..." % (len(data) // 1024, res))
                text, nf = make(data, res, strip, 0.85)
                say("Done in %.0f s, %d triangles. Ready." % (time.time() - t0, nf))
            self.reply(200, text, "text/plain; charset=utf-8")
        except Exception as e:
            traceback.print_exc(); say("Ready.")
            self.reply(500, json.dumps({"error": str(e)}))

if __name__ == "__main__":
    threading.Thread(target=load, daemon=True).start()
    print("3DPrintida photo helper on http://localhost:%d  (leave this window open)" % PORT, flush=True)
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
