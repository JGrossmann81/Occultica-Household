@echo off
setlocal
cd /d "%~dp0"
echo ===== 3DPrintida photo helper: one-time setup =====
echo Needs: Python 3.10 or 3.11 (python.org, tick "Add to PATH"), an NVIDIA graphics card, about 8 GB of disk and an internet connection.
set PY=
py -3.11 --version >nul 2>&1 && set PY=py -3.11
if "%PY%"=="" py -3.10 --version >nul 2>&1 && set PY=py -3.10
if "%PY%"=="" (echo Python 3.10 or 3.11 was not found. Install it from python.org and run this again. & pause & exit /b 1)
if not exist env (%PY% -m venv env || (echo Could not create the Python environment & pause & exit /b 1))
call env\Scripts\activate.bat
python -m pip install --upgrade pip
echo --- Installing PyTorch for NVIDIA (large download) ---
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121 || (echo PyTorch install failed & pause & exit /b 1)
echo --- Installing the other parts ---
pip install "numpy<2" omegaconf==2.3.0 Pillow einops==0.7.0 transformers==4.35.0 trimesh==4.0.5 rembg onnxruntime huggingface-hub "imageio[ffmpeg]" xatlas moderngl scikit-image || (echo Install failed & pause & exit /b 1)
if not exist TripoSR\tsr (
  echo --- Getting TripoSR ---
  powershell -NoProfile -Command "Invoke-WebRequest https://github.com/VAST-AI-Research/TripoSR/archive/refs/heads/main.zip -OutFile tsr.zip; Expand-Archive tsr.zip -DestinationPath . -Force; Rename-Item TripoSR-main TripoSR; Remove-Item tsr.zip"
)
if not exist TripoSR\tsr (echo Could not get TripoSR & pause & exit /b 1)
echo.
echo Setup finished. Now double-click start.bat
pause
