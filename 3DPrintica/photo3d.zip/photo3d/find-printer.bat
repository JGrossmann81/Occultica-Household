@echo off
cd /d "%~dp0"
echo Looking for your Elegoo printer...
where py >nul 2>&1 && (py -3 printer.py) || (python printer.py)
echo.
pause
