"""3DPrintica photo helper. Runs on YOUR PC and turns photos into 3D models with free, open AI models.
Engines: Hunyuan3D 2 (best), Hunyuan3D 2 Turbo (fast), Hunyuan3D 2 mini (light), Hunyuan3D 2 multi-view (2 to 4 photos),
and TripoSR (MIT licence). Start it with start.bat, then use the "Photo to 3D" tab on the 3DPrintica page.
Nothing leaves your computer except the one-time model downloads from Hugging Face."""
import re, socket, base64, gc, ipaddress, io, json, os, sys, time, threading, types, traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import printer, slicer, sdcp
import secrets, hmac, urllib.request, urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PORT = int(os.environ.get("P3D_PORT", "8788"))
HY_DIR = os.environ.get("HY_DIR", os.path.join(HERE, "Hunyuan3D-2"))
TSR_DIR = os.environ.get("TSR_DIR", os.path.join(HERE, "TripoSR"))
OUT = os.path.join(HERE, "outputs"); os.makedirs(OUT, exist_ok=True)
STATE = {"state": "starting", "msg": "Starting...", "device": "?", "vram": 0, "pct": 0, "engine": ""}
LOCK = threading.Lock()
M = {}

ENGINES = {
    "hy2":      dict(label="Hunyuan3D 2 (best quality)", repo="tencent/Hunyuan3D-2", sub="hunyuan3d-dit-v2-0", steps=(20, 30, 40, 50), up="y"),
    "hy2turbo": dict(label="Hunyuan3D 2 Turbo (fast)", repo="tencent/Hunyuan3D-2", sub="hunyuan3d-dit-v2-0-turbo", steps=(3, 5, 5, 8), up="y", flash=True),
    "hy2mini":  dict(label="Hunyuan3D 2 mini (light)", repo="tencent/Hunyuan3D-2mini", sub="hunyuan3d-dit-v2-mini", steps=(20, 30, 40, 50), up="y"),
    "hy2mv":    dict(label="Hunyuan3D 2 multi-view (2 to 4 photos)", repo="tencent/Hunyuan3D-2mv", sub="hunyuan3d-dit-v2-mv", steps=(20, 30, 40, 50), up="y", mv=True),
    "triposr":  dict(label="TripoSR (fast, MIT licence)", up="z"),
}
QUALITY = {"draft": (0, 256), "good": (1, 320), "high": (2, 384), "max": (3, 512)}  # (index into steps, octree resolution)


def say(msg, state=None, pct=None):
    STATE["msg"] = msg
    if state: STATE["state"] = state
    if pct is not None: STATE["pct"] = pct
    print(msg, flush=True)


def init():
    try:
        say("Starting up...", "loading")
        import torch
        dev = "cuda" if torch.cuda.is_available() else "cpu"
        M["torch"], M["dev"] = torch, dev
        if dev == "cuda":
            p = torch.cuda.get_device_properties(0)
            STATE["vram"] = round(p.total_memory / 2**30, 1); STATE["device"] = p.name
        else:
            STATE["device"] = "cpu"
        if not os.path.isdir(os.path.join(HY_DIR, "hy3dgen")) and not os.path.isdir(os.path.join(TSR_DIR, "tsr")):
            raise RuntimeError("The AI code was not found. Run setup.bat first.")
        say("Ready. The first photo downloads the AI model (a few GB), so it takes longer.", "ready")
    except Exception as e:
        traceback.print_exc(); say("Could not start: " + str(e), "error")


def unload():
    for k in ("pipe", "tsr"):
        M.pop(k, None)
    M["engine"] = None
    gc.collect()
    if M["dev"] == "cuda": M["torch"].cuda.empty_cache()


def install_mc_shim():
    try:
        import torchmcubes  # noqa
        return
    except Exception:
        pass
    import torch
    from mc_core import mc_numpy
    mod = types.ModuleType("torchmcubes")
    def marching_cubes(vol, thresh):
        v, f = mc_numpy(vol.detach().cpu().numpy(), float(thresh))
        return torch.from_numpy(v), torch.from_numpy(f)
    mod.marching_cubes = marching_cubes
    sys.modules["torchmcubes"] = mod


def load_engine(name):
    if M.get("engine") == name: return
    unload(); torch, dev = M["torch"], M["dev"]
    cfg = ENGINES[name]
    say("Loading " + cfg["label"] + ". The first time this downloads the model, which can take several minutes...", pct=0)
    if name == "triposr":
        sys.path.insert(0, TSR_DIR); install_mc_shim()
        from tsr.system import TSR
        m = TSR.from_pretrained("stabilityai/TripoSR", config_name="config.yaml", weight_name="model.ckpt")
        m.renderer.set_chunk_size(8192); m.to(dev); M["tsr"] = m
    else:
        if HY_DIR not in sys.path: sys.path.insert(0, HY_DIR)
        from hy3dgen.shapegen import Hunyuan3DDiTFlowMatchingPipeline
        pipe = Hunyuan3DDiTFlowMatchingPipeline.from_pretrained(cfg["repo"], subfolder=cfg["sub"], use_safetensors=True, device=dev)
        if cfg.get("flash"):
            try: pipe.enable_flashvdm(mc_algo="mc")
            except Exception as e: print("FlashVDM not available:", e)
        M["pipe"] = pipe
    M["engine"] = name


def cut_out(img, strip):
    """Hunyuan wants the subject on a transparent background."""
    if strip or img.mode != "RGBA":
        if "rb" not in M:
            from hy3dgen.rembg import BackgroundRemover
            M["rb"] = BackgroundRemover()
        return M["rb"](img.convert("RGB"))
    return img


def reducer(v, f, n):
    import pymeshlab
    ms = pymeshlab.MeshSet(); ms.add_mesh(pymeshlab.Mesh(vertex_matrix=v, face_matrix=f))
    ms.meshing_decimation_quadric_edge_collapse(targetfacenum=n, preserveboundary=True, preservenormal=True, preservetopology=True, qualitythr=0.5)
    m = ms.current_mesh(); return m.vertex_matrix(), m.face_matrix()


def run_hunyuan(req, imgs, steps, octree):
    torch, np = M["torch"], M["np"]
    cfg = ENGINES[req["engine"]]; pipe = M["pipe"]
    strip = bool(req.get("strip", True))
    if cfg.get("mv"):
        image = {k: cut_out(v, strip) for k, v in imgs.items()}
    else:
        image = cut_out(imgs["front"], strip)
    gen = torch.Generator().manual_seed(int(req.get("seed", 1234)))
    chunks = 8000 if STATE["vram"] < 12 else 20000
    def cb(i, t, outputs):
        STATE["pct"] = int(100 * (i + 1) / max(1, steps)); STATE["msg"] = "Shaping the model: step %d of %d" % (i + 1, steps)
        if i + 1 >= steps: STATE["msg"] = "Building the surface (resolution %d). This part can take a minute..." % octree
    kw = dict(image=image, num_inference_steps=steps, guidance_scale=float(req.get("guidance", 5.0)), generator=gen,
              octree_resolution=octree, num_chunks=chunks, callback=cb, callback_steps=1)
    mesh = pipe(**kw)[0]
    if mesh is None: raise RuntimeError("No object was found in the photo. Try a clearer photo with the whole subject in view.")
    return np.asarray(mesh.vertices, dtype=np.float64), np.asarray(mesh.faces, dtype=np.int64)


def run_triposr(req, imgs, octree):
    torch, np = M["torch"], M["np"]
    from PIL import Image
    import rembg
    from tsr.utils import remove_background, resize_foreground
    img = imgs["front"]
    if req.get("strip", True) or img.mode != "RGBA":
        if "sess" not in M: M["sess"] = rembg.new_session()
        img = resize_foreground(remove_background(img, M["sess"]), 0.85)
        a = np.array(img).astype(np.float32) / 255.0
        a = a[:, :, :3] * a[:, :, 3:4] + (1 - a[:, :, 3:4]) * 0.5
        img = Image.fromarray((a * 255.0).astype(np.uint8))
    else:
        img = img.convert("RGB")
    with torch.no_grad():
        codes = M["tsr"]([img], device=M["dev"])
        mesh = M["tsr"].extract_mesh(codes, False, resolution=min(octree, 512))[0]
    return np.asarray(mesh.vertices, dtype=np.float64), np.asarray(mesh.faces, dtype=np.int64)


def make(req):
    import numpy as np
    from PIL import Image
    import meshfix
    M["np"] = np
    name = req.get("engine", "hy2")
    if name not in ENGINES: raise ValueError("Unknown engine " + str(name))
    cfg = ENGINES[name]
    imgs = {k: Image.open(io.BytesIO(base64.b64decode(b))) for k, b in (req.get("views") or {}).items() if b}
    for k in imgs: imgs[k].load()
    if "front" not in imgs: raise ValueError("Add a front photo first.")
    if cfg.get("mv") and len(imgs) < 2: raise ValueError("Multi-view needs at least two photos: the front and one more (back, left or right).")
    qi, octree = QUALITY.get(req.get("quality", "high"), QUALITY["high"])
    steps = (cfg.get("steps") or (0, 0, 0, 0))[qi]
    if STATE["vram"] and STATE["vram"] < 12: octree = min(octree, 448)
    t0 = time.time(); stamp = time.strftime("%Y%m%d_%H%M%S")
    load_engine(name)
    say("Working..."); STATE["pct"] = 0
    while True:
        try:
            v, f = run_triposr(req, imgs, octree) if name == "triposr" else run_hunyuan(req, imgs, steps, octree)
            break
        except M["torch"].cuda.OutOfMemoryError:
            M["torch"].cuda.empty_cache(); gc.collect()
            if octree <= 256: raise RuntimeError("The graphics card ran out of memory. Close other programs, or pick Draft quality or the mini engine.")
            octree = max(256, octree - 64); say("Out of video memory, trying again at resolution %d..." % octree)
    say("Cleaning up the mesh for printing...", pct=100)
    smooth = int(req.get("smooth", 2)) * 5
    v, f, info = meshfix.clean(v, f, smooth_iters=smooth, target_faces=int(req.get("faces", 300000)), reducer=reducer)
    data = meshfix.stl_bytes(v, f)
    with open(os.path.join(OUT, stamp + "_" + name + ".stl"), "wb") as fh: fh.write(data)
    imgs["front"].save(os.path.join(OUT, stamp + "_input.png"))
    info.update(engine=cfg["label"], up=cfg["up"], seconds=round(time.time() - t0, 1), octree=octree, steps=steps)
    return data, info


# ---------- slice and send (runs on the computer that has ElegooSlicer, normally the shop PC) ----------
# Safety: by default this helper only listens on this computer. "Shop mode" (start-shop.bat) also lets OTHER computers on your
# network send a model to be sliced, but only with the PIN, and they can only send a model and read the result. They can never
# choose which program runs or give it any text: the slicer command is fixed in slicer.py and settings are picked by preset name.
JOBS = {}
FAILS = {}
MAX_BODY = 120 * 1024 * 1024
LAN_PATHS = ("/shop/status", "/shop/slice", "/shop/job", "/shop/gcode")
MB_RE = re.compile(r"^[0-9A-Za-z]{8,40}$")


def lan_pin():
    c = slicer.load_cfg()
    if not c.get("pin"): c = slicer.save_cfg({"pin": secrets.token_urlsafe(9)})
    return c["pin"]


def private_ip(ip):
    try: a = ipaddress.ip_address(ip); return a.version == 4 and a.is_private and not a.is_loopback and not a.is_unspecified
    except Exception: return False


def pin_ok(addr, given):
    now = time.time(); f = [t for t in FAILS.get(addr, []) if now - t < 300]
    if len(f) >= 8: return False
    if hmac.compare_digest(str(given or ""), lan_pin()): return True
    f.append(now); FAILS[addr] = f; return False


def job_run(jid, req):
    j = JOBS[jid]
    def upd(**k): j.update(k)
    try:
        c = slicer.load_cfg()
        upd(stage="slicing", msg="Slicing with your slicer settings...", pct=5)
        gcode, tool = slicer.slice_stl(base64.b64decode(req["stl"]), names=req.get("profile"), name=req.get("name", "model"), log=lambda m: upd(msg=m))
        size = os.path.getsize(gcode); j["gcode"] = gcode; upd(stage="sliced", msg="Sliced: %.1f MB of G-code." % (size / 1e6), pct=40, tool=tool[-300:])
        if not (req.get("send") or req.get("start")): upd(stage="done", done=True, msg="Sliced. Download the G-code below.", pct=100); return
        ip = req.get("ip") or c.get("printer_ip")
        if not private_ip(ip or ""): raise RuntimeError("No printer address yet. Press Find my printer first.")
        mb = c.get("mainboard") if c.get("printer_ip") == ip else ""
        if not (mb and MB_RE.match(mb)):
            info = printer.ask(ip, 2.0) or printer.ask(ip, 2.0)
            mb = (info or {}).get("id", "")
            if not MB_RE.match(mb or ""): raise RuntimeError("The printer at %s did not answer. Is it on and on the same network?" % ip)
            slicer.save_cfg({"printer_ip": ip, "mainboard": mb})
        upd(stage="uploading", msg="Sending to the printer...", pct=45)
        name = re.sub(r"[^A-Za-z0-9_-]+", "_", req.get("name", "model"))[:40] + "_" + time.strftime("%H%M") + ".gcode"
        sdcp.upload(ip, gcode, name, progress=lambda a, b: upd(pct=45 + int(45 * a / b), msg="Sending to the printer... %d%%" % (100 * a // b)))
        if req.get("start"):
            upd(stage="starting", msg="Starting the print...", pct=95)
            r = sdcp.start_print(ip, mb, name, leveling=bool(req.get("leveling", True)))
            if not r.get("ok"): raise RuntimeError("The file is on the printer, but it would not start it (code %s). Start it from the printer's screen." % r.get("ack"))
            upd(stage="done", done=True, pct=100, msg="Printing started: " + name)
        else:
            upd(stage="done", done=True, pct=100, msg="Sent to the printer as " + name + ". Start it from the printer's screen.")
    except Exception as e:
        traceback.print_exc(); upd(stage="error", done=True, error=str(e), msg=str(e))


def shop_get(path, q, local):
    if path == "/shop/status":
        st = slicer.status(); pres = slicer.list_presets()
        st["presets"] = {k: [e["name"] for e in v] for k, v in pres.items()}; st["host"] = socket.gethostname()
        c = slicer.load_cfg(); st["remote"] = c.get("remote", "") if local else ""
        if not local: st.pop("exe", None); st.pop("exes", None)
        return 200, json.dumps(st), "application/json"
    if path == "/shop/job":
        j = JOBS.get(q.get("id", [""])[0])
        if not j: return 404, "{}", "application/json"
        return 200, json.dumps({k: v for k, v in j.items() if k != "gcode"}), "application/json"
    if path == "/shop/gcode":
        j = JOBS.get(q.get("id", [""])[0])
        if not j or not j.get("gcode"): return 404, "{}", "application/json"
        return 200, open(j["gcode"], "rb").read(), "application/octet-stream"
    return 404, "{}", "application/json"


def shop_post(path, body, local):
    req = json.loads(body or b"{}")
    if path == "/shop/config":
        if not local: return 403, json.dumps({"error": "Settings can only be changed on the shop computer itself."}), "application/json"
        keep = {}
        if isinstance(req.get("profile"), dict): keep["profile"] = {k: str(req["profile"].get(k, ""))[:200] for k in ("machine", "process", "filament")}
        if req.get("printer_ip") is not None:
            if req["printer_ip"] and not private_ip(req["printer_ip"]): return 400, json.dumps({"error": "That is not an address on your own network."}), "application/json"
            keep["printer_ip"] = req["printer_ip"]
        if req.get("mainboard") is not None and (req["mainboard"] == "" or MB_RE.match(str(req["mainboard"]))): keep["mainboard"] = req["mainboard"]
        if req.get("exe") is not None:
            if req["exe"] and not slicer.valid_exe(req["exe"]): return 400, json.dumps({"error": "That file does not look like a slicer program."}), "application/json"
            keep["exe"] = req["exe"]
        if req.get("remote") is not None:
            m = re.match(r"^http://(\d+\.\d+\.\d+\.\d+):(\d{2,5})$", req["remote"] or "")
            if req["remote"] and not (m and private_ip(m.group(1))): return 400, json.dumps({"error": "Use the shop computer's address like http://192.168.1.50:8788"}), "application/json"
            keep["remote"] = req["remote"]
        if "remote_pin" in req: keep["remote_pin"] = str(req["remote_pin"])[:40]
        if "lan" in req: keep["lan"] = bool(req["lan"])
        slicer.save_cfg(keep); return 200, json.dumps({"ok": True}), "application/json"
    if path == "/shop/slice":
        if len(req.get("stl", "")) < 20: return 400, json.dumps({"error": "No model was sent."}), "application/json"
        if req.get("ip") and not private_ip(req["ip"]): return 400, json.dumps({"error": "That is not an address on your own network."}), "application/json"
        safe = {k: req.get(k) for k in ("stl", "name", "send", "start", "leveling", "ip")}; safe["profile"] = req.get("profile") if isinstance(req.get("profile"), dict) else {}
        jid = secrets.token_urlsafe(6); JOBS[jid] = {"stage": "queued", "msg": "Queued...", "pct": 0}
        threading.Thread(target=job_run, args=(jid, safe), daemon=True).start()
        return 200, json.dumps({"id": jid}), "application/json"
    return 404, "{}", "application/json"


def proxy(method, pathq, body, remote, pin):
    rq = urllib.request.Request(remote.rstrip("/") + pathq, data=body if method == "POST" else None, method=method, headers={"X-Pin": pin, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(rq, timeout=900) as r: return r.status, r.read(), r.headers.get("Content-Type", "application/json")
    except urllib.error.HTTPError as e: return e.code, e.read(), "application/json"
    except Exception as e: return 502, json.dumps({"error": "Could not reach the shop computer's helper (" + str(e) + "). Is start-shop.bat running there, and are both computers on the same network?"}).encode(), "application/json"


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def cors(self):
        o = self.headers.get("Origin", "")
        if o.startswith(("https://jgrossmann81.github.io", "http://localhost", "http://127.0.0.1")) or not o: self.send_header("Access-Control-Allow-Origin", o or "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Pin")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Expose-Headers", "X-Info")
    def reply(self, code, body, ctype="application/json", extra=None):
        b = body.encode() if isinstance(body, str) else body
        self.send_response(code); self.cors()
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def local(self): return self.client_address[0] in ("127.0.0.1", "::1")
    def shop(self, method, body=b""):
        u = urlparse(self.path)
        if not self.local():
            if u.path not in LAN_PATHS: return self.reply(403, json.dumps({"error": "Not allowed from another computer."}))
            if not pin_ok(self.client_address[0], self.headers.get("X-Pin", "")): return self.reply(401, json.dumps({"error": "Wrong PIN for the shop helper."}))
        else:
            c = slicer.load_cfg()
            if c.get("remote") and not u.path.startswith("/shop/config"):
                code, b, ct = proxy(method, self.path, body, c["remote"], c.get("remote_pin", ""))
                return self.reply(code, b, ct)
        try:
            code, b, ct = shop_get(u.path, parse_qs(u.query), self.local()) if method == "GET" else shop_post(u.path, body, self.local())
            self.reply(code, b, ct)
        except Exception as e: traceback.print_exc(); self.reply(500, json.dumps({"error": str(e)}))
    def do_OPTIONS(self): self.reply(204, "")
    def do_GET(self):
        if urlparse(self.path).path.startswith("/shop/"): return self.shop("GET")
        if not self.local(): return self.reply(403, "{}")
        if urlparse(self.path).path == "/ping":
            self.reply(200, json.dumps(dict(STATE, ok=True, app="3dprintica-photo3d", engines={k: v["label"] for k, v in ENGINES.items()})))
        elif urlparse(self.path).path == "/printer/find":
            try: pr, notes = printer.find(); self.reply(200, json.dumps({"printers": pr, "notes": notes}))
            except Exception as e: self.reply(500, json.dumps({"error": str(e)}))
        elif urlparse(self.path).path == "/printer/check":
            try:
                ip = parse_qs(urlparse(self.path).query).get("ip", [""])[0]
                if not ipaddress.ip_address(ip).is_private: raise ValueError("Only addresses on your own network can be checked.")
                self.reply(200, json.dumps({"ip": ip, "reachable": printer.port_open(ip, printer.WS_PORT, 1.5), "info": printer.ask(ip, 1.5)}))
            except Exception as e: self.reply(400, json.dumps({"error": str(e)}))
        else: self.reply(404, "{}")
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n > MAX_BODY: return self.reply(413, json.dumps({"error": "That file is too large."}))
        if urlparse(self.path).path.startswith("/shop/"): return self.shop("POST", self.rfile.read(n))
        if not self.local(): return self.reply(403, "{}")
        if urlparse(self.path).path != "/make": return self.reply(404, "{}")
        if STATE["state"] not in ("ready",): return self.reply(503, json.dumps({"error": STATE["msg"]}))
        body = self.rfile.read(n)
        try:
            req = json.loads(body)
            with LOCK:
                STATE["state"] = "busy"
                try: data, info = make(req)
                finally: STATE["state"] = "ready"
            say("Done in %.0f s: %d triangles, %s. Ready." % (info["seconds"], info["faces"], "solid" if info["watertight"] else "has small gaps"), pct=100)
            self.reply(200, data, "application/octet-stream", {"X-Info": json.dumps(info)})
        except Exception as e:
            traceback.print_exc(); say("Ready.")
            self.reply(500, json.dumps({"error": str(e)}))


if __name__ == "__main__":
    threading.Thread(target=init, daemon=True).start()
    print("3DPrintica photo helper on http://localhost:%d  (leave this window open)" % PORT, flush=True)
    lan = os.environ.get("P3D_LAN") == "1"
    if lan: print("SHOP MODE: other computers on your network can send models here to be sliced. PIN: %s   (keep it private)" % lan_pin(), flush=True)
    ThreadingHTTPServer(("0.0.0.0" if lan else "127.0.0.1", PORT), H).serve_forever()
