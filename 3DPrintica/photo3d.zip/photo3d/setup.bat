@echo off
setlocal
cd /d "%~dp0"
echo ===== 3DPrintica photo helper: one-time setup =====
echo Needs: Python 3.10 or 3.11 (python.org, tick "Add python.exe to PATH"), an NVIDIA graphics card,
echo about 15 GB of free disk space and an internet connection. This takes 10 to 30 minutes.
echo.
set PY=
py -3.11 --version >nul 2>&1 && set PY=py -3.11
if "%PY%"=="" py -3.10 --version >nul 2>&1 && set PY=py -3.10
if "%PY%"=="" (echo Python 3.10 or 3.11 was not found. Install it from python.org and run this again. & pause & exit /b 1)
if not exist env (%PY% -m venv env || (echo Could not create the Python environment & pause & exit /b 1))
call env\Scripts\activate.bat
python -m pip install --upgrade pip
echo --- Installing PyTorch for NVIDIA (large download) ---
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124 || (echo PyTorch install failed & pause & exit /b 1)
echo --- Installing the other parts ---
pip install "numpy<2" scipy scikit-image Pillow opencv-python einops omegaconf pyyaml tqdm safetensors accelerate "huggingface_hub<0.26" "transformers==4.46.3" "diffusers==0.31.0" trimesh pymeshlab rembg onnxruntime || (echo Install failed & pause & exit /b 1)
if not exist Hunyuan3D-2\hy3dgen (
  echo --- Getting Hunyuan3D 2 ---
  powershell -NoProfile -Command "Invoke-WebRequest https://github.com/Tencent-Hunyuan/Hunyuan3D-2/archive/refs/heads/main.zip -OutFile hy.zip; Expand-Archive hy.zip -DestinationPath . -Force; Rename-Item Hunyuan3D-2-main Hunyuan3D-2; Remove-Item hy.zip"
)
if not exist Hunyuan3D-2\hy3dgen (echo Could not get Hunyuan3D 2 & pause & exit /b 1)
echo --- Optional: TripoSR (a second, faster engine) ---
pip install xatlas moderngl "imageio[ffmpeg]" || echo Skipping TripoSR extras
if not exist TripoSR\tsr (
  powershell -NoProfile -Command "Invoke-WebRequest https://github.com/VAST-AI-Research/TripoSR/archive/refs/heads/main.zip -OutFile tsr.zip; Expand-Archive tsr.zip -DestinationPath . -Force; Rename-Item TripoSR-main TripoSR; Remove-Item tsr.zip" || echo Skipping TripoSR
)
echo.
echo Setup finished. Now double-click start.bat
pause
