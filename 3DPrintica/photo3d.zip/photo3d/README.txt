3DPrintica: Photo to 3D on your own PC
1. Put this folder anywhere (for example Documents\photo3d).
2. Double-click setup.bat once (10 to 30 minutes, about 15 GB).
3. Double-click start.bat and leave the window open.
4. Open the 3DPrintica page, choose "Photo to 3D", pick a photo, press Make 3D model.
   The first photo with each engine downloads that engine's model (2 to 4 GB), so it is slow once.
Finished models are also saved in the "outputs" folder next to server.py.

Engines
  Hunyuan3D 2           best shapes. About 6 GB of video memory. Good first choice.
  Hunyuan3D 2 Turbo     same family, about 5x faster, slightly less crisp.
  Hunyuan3D 2 mini      lightest, for 6 GB cards.
  Hunyuan3D 2 multi-view  give it 2 to 4 photos (front plus back, left, right) for a far better back side.
  TripoSR               fast and simple.

Licences: TripoSR is MIT. Hunyuan3D 2 is the Tencent Hunyuan Community licence: free for personal and
non-commercial use, and not available in the EU, UK or South Korea. If you plan to SELL prints made from it, read its licence or use TripoSR.

Photo tips: one subject, the whole thing in view, soft even light, plain background, a front or slight three-quarter view.
Statues, figurines, toys, props and faces from a straight-on photo work best. Fine text and thin wires do not.
