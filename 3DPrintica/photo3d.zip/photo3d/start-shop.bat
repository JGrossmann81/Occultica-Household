@echo off
cd /d "%~dp0"
echo SHOP MODE: this computer will slice models sent from your other computer and send them to the printer.
echo Windows may ask to allow Python through the firewall: allow it for PRIVATE networks only.
echo Note the PIN printed below. You will type it once on the other computer.
echo.
set P3D_LAN=1
if exist env\Scripts\python.exe (env\Scripts\python.exe server.py) else (py -3 server.py)
pause
